import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq

# Leer archivo 
data=np.loadtxt('postProcessing/forceCoeffs/0/forceCoeffs.dat')

# Columnas: Time, Cm, Cd, Cl, Cl_f, Cl_r
time = data[:, 0]
Cm = data[:, 1]
Cd = data[:, 2]
Cl = data[:, 3]

# Promedios finales (final 67%)
cutoff = int(0.67 * len(Cd))
dtrms=time[-1]-time[cutoff]
Cd_final=1/dtrms*np.trapezoid(Cd[cutoff:],time[cutoff:])
Cl_final=1/dtrms*np.trapezoid(Cl[cutoff:],time[cutoff:])
# Valores RMS
Cl_rms=np.sqrt(1/dtrms*np.trapezoid((Cl[cutoff:]-Cl_final)**2,time[cutoff:]))
Cd_rms=np.sqrt(1/dtrms*np.trapezoid((Cd[cutoff:]-Cd_final)**2,time[cutoff:]))
# Crear figura con un solo eje Y
fig, ax = plt.subplots(figsize=(12, 7))

# Graficar Cd
ax.plot(time[cutoff:], Cd[cutoff:], alpha=0.3, linewidth=0.8, color='red', label="Cd instantaneo")
#ax.plot(time, Cd_mean, linewidth=2.5, color='darkred', label="Promedio acumulado de Cd")
ax.axhline(Cd_final, linestyle="--", color='darkred', linewidth=2,
           label=f"Cd promedio final")

ax.set_xlabel("Time (s)")
ax.set_ylabel("C_d ")
ax.grid(True, alpha=0.3)
ax.legend(loc='best')
#ax.set_xlim([0, time.max()])

plt.tight_layout()
plt.savefig("coeficientes_Cd.png", dpi=300, bbox_inches='tight')
plt.show()

fig, ax2 = plt.subplots(figsize=(12, 7))
# Graficar Cl (mismo eje)
ax2.plot(time, Cl, alpha=0.3, linewidth=0.8, color='blue', label="Cl instantaneo")
#ax2.plot(time, Cl_mean, linewidth=2.5, color='darkblue', label="Promedio acumulado de Cl")
ax2.axhline(Cl_final, linestyle="--", color='darkblue', linewidth=2,
           label=f"Cl promedio final")
#ax2.axhline(0, linestyle=":", color='gray', linewidth=1, alpha=0.5, label="Simetria (Cl=0)")

ax2.set_xlabel("Time (s)")
ax2.set_ylabel("C_l ")
ax2.grid(True, alpha=0.3)
ax2.legend(loc='best')
ax2.set_xlim([0, time.max()])

plt.tight_layout()
#plt.savefig("coeficientes_Cd.png", dpi=300, bbox_inches='tight')
plt.show()

# Resultados en consola
print("\n" + "="*60)
print("RESULTADOS FINALES")
print("="*60)
print(f"Cd promedio final = {Cd_final:.6f}")
print(f"Cd_rms = {Cd_rms:.6f}")
print(f"Cl promedio final = {Cl_final:.6f}")
print(f"Cl_rms = {Cl_rms:.6f}")
print("="*60)

# ==========================================================
# CALCULO DEL NUMERO DE STROUHAL MEDIANTE FFT
# ==========================================================

from scipy.fft import fft, fftfreq

print("\nCALCULO DEL NUMERO DE STROUHAL")
print("-"*60)

# Solo usar la parte estable de la simulacion
Cl_fft = Cl[cutoff:20]
time_fft = time[cutoff:20]

# Remover el valor medio (muy importante para la FFT)
Cl_fft = Cl_fft - np.mean(Cl_fft)

# Paso temporal
dt = np.mean(np.diff(time_fft))

# Numero de muestras
N = len(Cl_fft)

# Transformada rapida de Fourier
Y = fft(Cl_fft)

# Frecuencias asociadas
freq = fftfreq(N, dt)

# Solo frecuencias positivas
mask = freq > 0
freq = freq[mask]
amplitud = np.abs(Y[mask])

# Frecuencia dominante
indice = np.argmax(amplitud)
f_dominante = freq[indice]

# Datos del caso OpenFOAM
U_inf = 25.0      # m/s
L_ref = 0.06      # m

# Numero de Strouhal
St = f_dominante * L_ref / U_inf

print(f"Frecuencia dominante = {f_dominante:.4f} Hz")
print(f"Numero de Strouhal   = {St:.5f}")

# Grafica del espectro
plt.figure(figsize=(10,5))
plt.semilogy(freq, amplitud, color='darkgreen')
plt.scatter(f_dominante,
            amplitud[indice],
            color='red',
            zorder=5,
            label=f"Pico = {f_dominante:.2f} Hz")

plt.xlabel("Frecuencia [Hz]")
plt.ylabel("Amplitud FFT")
plt.grid(alpha=0.3)
plt.legend()

plt.tight_layout()
#plt.savefig("FFT_Cl.png", dpi=300)
plt.show()
